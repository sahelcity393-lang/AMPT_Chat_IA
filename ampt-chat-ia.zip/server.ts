import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini API for external integration
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

  // API Route for external integration using the generated keys
  app.post("/api/v1/chat", async (req, res) => {
    const { message, apiKey } = req.body;

    if (!apiKey) {
      return res.status(401).json({ error: "API Key is required" });
    }

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    try {
      // Simple chat completion for the external API
      const model = (ai as any).getGenerativeModel({ model: "gemini-2.0-flash" });
      const result = await model.generateContent(message);
      const response = await result.response;
      res.json({ reply: response.text() });
    } catch (error) {
      console.error("External API Error:", error);
      res.status(500).json({ error: "Failed to process request" });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "AMPT Chat IA API" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
