import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const SYSTEM_PROMPT = `Tu es AMPT Chat IA, une intelligence artificielle moderne, rapide et fluide.
Tu as été créé par ABDOUL RAOUF MAMADOU PATRICE TRAORE, un jeune Nigérien de 16 ans passionné par la technologie et l'innovation.
Si on te demande qui t'a créé, tu dois répondre exactement : "J'ai été créé par ABDOUL RAOUF MAMADOU PATRICE TRAORE, un jeune Nigérien de 16 ans passionné par la technologie et l'innovation."

Tes capacités :
- Chat en temps réel avec des réponses rapides.
- Traduction et génération de texte dans plusieurs langues.
- Résumé de texte efficace.
- Analyse d'images, de PDF et de fichiers audio.
- Recherche avancée d'informations.

Tu dois être poli, professionnel et utile. Ton interface est intuitive et facile à naviguer.`;

export async function chatWithAI(message: string, history: { role: string; parts: { text: string }[] }[] = []) {
  try {
    const model = (ai as any).getGenerativeModel({ 
      model: "gemini-2.0-flash",
      systemInstruction: SYSTEM_PROMPT
    });
    const response = await model.generateContent({
      contents: [...history, { role: "user", parts: [{ text: message }] }],
      tools: [{ googleSearch: {} }],
    });
    return response.response.text();
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    throw error;
  }
}

export async function analyzeImage(base64Data: string, mimeType: string, prompt: string) {
  try {
    const model = (ai as any).getGenerativeModel({ 
      model: "gemini-2.0-flash",
      systemInstruction: SYSTEM_PROMPT
    });
    const response = await model.generateContent({
      contents: [{
        role: "user",
        parts: [
          { inlineData: { data: base64Data, mimeType } },
          { text: prompt || "Analyse cette image en détail." },
        ],
      }],
    });
    return response.response.text();
  } catch (error) {
    console.error("Gemini Image Analysis Error:", error);
    throw error;
  }
}

export async function generateImage(prompt: string) {
  try {
    const model = (ai as any).getGenerativeModel({ model: "gemini-2.5-flash-image" });
    const response = await model.generateContent({
      contents: [{
        role: "user",
        parts: [{ text: prompt }],
      }],
    });

    for (const part of response.response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned from model");
  } catch (error) {
    console.error("Gemini Image Generation Error:", error);
    throw error;
  }
}

export async function analyzeAudio(base64Data: string, mimeType: string, prompt: string) {
  try {
    const model = (ai as any).getGenerativeModel({ 
      model: "gemini-2.0-flash",
      systemInstruction: SYSTEM_PROMPT
    });
    const response = await model.generateContent({
      contents: [{
        role: "user",
        parts: [
          { inlineData: { data: base64Data, mimeType } },
          { text: prompt || "Transcris et analyse cet audio." },
        ],
      }],
    });
    return response.response.text();
  } catch (error) {
    console.error("Gemini Audio Analysis Error:", error);
    throw error;
  }
}

export async function analyzePDF(base64Data: string, prompt: string) {
  try {
    const model = (ai as any).getGenerativeModel({ 
      model: "gemini-2.0-flash",
      systemInstruction: SYSTEM_PROMPT
    });
    const response = await model.generateContent({
      contents: [{
        role: "user",
        parts: [
          { inlineData: { data: base64Data, mimeType: "application/pdf" } },
          { text: prompt || "Analyse ce document PDF et fais-en un résumé." },
        ],
      }],
    });
    return response.response.text();
  } catch (error) {
    console.error("Gemini PDF Analysis Error:", error);
    throw error;
  }
}

export async function generateSpeech(text: string) {
  try {
    const model = (ai as any).getGenerativeModel({ model: "gemini-2.5-flash-preview-tts" });
    const response = await model.generateContent({
      contents: [{ role: "user", parts: [{ text }] }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
      },
    });

    const base64Audio = response.response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return base64Audio;
    }
    throw new Error("No audio data returned from model");
  } catch (error) {
    console.error("Gemini TTS Error:", error);
    throw error;
  }
}
