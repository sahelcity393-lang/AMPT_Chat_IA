import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Plus, 
  Image as ImageIcon, 
  Mic, 
  FileText, 
  Settings, 
  LogOut, 
  User, 
  Moon, 
  Sun, 
  Search, 
  Menu, 
  X, 
  Key, 
  Copy, 
  Check,
  Volume2,
  Trash2,
  MessageSquare
} from 'lucide-react';
import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  doc, 
  updateDoc, 
  deleteDoc,
  getDocs,
  getDocFromServer
} from 'firebase/firestore';
import { auth, db, googleProvider, githubProvider, facebookProvider, appleProvider } from './lib/firebase';
import { chatWithAI, analyzeImage, generateImage, analyzeAudio, analyzePDF, generateSpeech } from './lib/gemini';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Toaster, toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

// --- Types ---
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  type: 'text' | 'image' | 'audio' | 'file';
  mediaUrl?: string;
  createdAt: any;
}

interface Chat {
  id: string;
  title: string;
  userId: string;
  createdAt: any;
  updatedAt: any;
}

interface ApiKey {
  id: string;
  key: string;
  name: string;
  createdAt: any;
}

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Firestore Connection Test ---
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. The client is offline.");
          toast.error("Erreur de connexion à la base de données. Vérifiez votre configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // --- Auth & Initial Data ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'chats'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chatList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chat));
      setChats(chatList);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!currentChatId) {
      setMessages([]);
      return;
    }

    const q = query(
      collection(db, `chats/${currentChatId}/messages`),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
      setMessages(msgList);
    });

    return () => unsubscribe();
  }, [currentChatId]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'api_keys'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setApiKeys(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ApiKey)));
    });
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // --- Actions ---
  const handleLogin = async (provider: any) => {
    try {
      await signInWithPopup(auth, provider);
      toast.success('Connexion réussie !');
    } catch (error) {
      console.error(error);
      toast.error('Erreur de connexion');
    }
  };

  const handleLogout = () => signOut(auth);

  const createNewChat = async () => {
    if (!user) return;
    const docRef = await addDoc(collection(db, 'chats'), {
      userId: user.uid,
      title: 'Nouveau Chat',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    setCurrentChatId(docRef.id);
    setIsSidebarOpen(false);
  };

  const deleteChat = async (id: string) => {
    await deleteDoc(doc(db, 'chats', id));
    if (currentChatId === id) setCurrentChatId(null);
  };

  const sendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || !user || isProcessing) return;

    let chatId = currentChatId;
    if (!chatId) {
      const docRef = await addDoc(collection(db, 'chats'), {
        userId: user.uid,
        title: input.slice(0, 30),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      chatId = docRef.id;
      setCurrentChatId(chatId);
    }

    const userMsg = input;
    setInput('');
    setIsProcessing(true);

    try {
      // Add user message
      await addDoc(collection(db, `chats/${chatId}/messages`), {
        role: 'user',
        content: userMsg,
        type: 'text',
        createdAt: serverTimestamp(),
      });

      await updateDoc(doc(db, 'chats', chatId), { updatedAt: serverTimestamp() });

      // Get AI response
      const history = messages.map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      }));

      let aiResponse = '';
      if (userMsg.toLowerCase().startsWith('/image ')) {
        const prompt = userMsg.replace('/image ', '');
        aiResponse = await generateImage(prompt);
        await addDoc(collection(db, `chats/${chatId}/messages`), {
          role: 'assistant',
          content: `Image générée pour : ${prompt}`,
          type: 'image',
          mediaUrl: aiResponse,
          createdAt: serverTimestamp(),
        });
      } else {
        aiResponse = await chatWithAI(userMsg, history);
        await addDoc(collection(db, `chats/${chatId}/messages`), {
          role: 'assistant',
          content: aiResponse,
          type: 'text',
          createdAt: serverTimestamp(),
        });
      }
    } catch (error) {
      console.error(error);
      toast.error('Erreur lors de l\'envoi du message');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !currentChatId) return;

    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      try {
        let response = '';
        if (file.type.startsWith('image/')) {
          response = await analyzeImage(base64, file.type, "Analyse cette image.");
        } else if (file.type === 'application/pdf') {
          response = await analyzePDF(base64, "Analyse ce PDF.");
        } else if (file.type.startsWith('audio/')) {
          response = await analyzeAudio(base64, file.type, "Transcris cet audio.");
        }

        await addDoc(collection(db, `chats/${currentChatId}/messages`), {
          role: 'user',
          content: `Fichier analysé : ${file.name}`,
          type: 'file',
          createdAt: serverTimestamp(),
        });

        await addDoc(collection(db, `chats/${currentChatId}/messages`), {
          role: 'assistant',
          content: response,
          type: 'text',
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        toast.error('Erreur lors de l\'analyse du fichier');
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const generateUserApiKey = async () => {
    if (!user) return;
    const newKey = 'ampt_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    await addDoc(collection(db, 'api_keys'), {
      userId: user.uid,
      key: newKey,
      name: `Clé ${apiKeys.length + 1}`,
      createdAt: serverTimestamp(),
    });
    toast.success('Clé API générée !');
  };

  const speakText = async (text: string) => {
    try {
      const base64 = await generateSpeech(text);
      const audio = new Audio(`data:audio/mp3;base64,${base64}`);
      audio.play();
    } catch (error) {
      toast.error('Erreur de synthèse vocale');
    }
  };

  const startVoiceRecognition = () => {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('La reconnaissance vocale n\'est pas supportée par votre navigateur');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
    };
    recognition.start();
    toast.info('Écoute en cours...');
  };

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <motion.div 
          animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className={`min-h-screen flex items-center justify-center p-4 bg-background text-foreground transition-colors duration-300`}>
        <Card className="w-full max-w-md p-8 space-y-8 border-2 border-primary/20 shadow-2xl bg-card">
          <div className="text-center space-y-2">
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="inline-block p-4 rounded-2xl bg-primary/10 mb-4"
            >
              <MessageSquare className="w-12 h-12 text-primary" />
            </motion.div>
            <h1 className="text-4xl font-bold tracking-tight">AMPT Chat IA</h1>
            <p className="text-muted-foreground">L'IA moderne par Abdoul Raouf</p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <Button variant="outline" className="h-12 text-lg font-medium" onClick={() => handleLogin(googleProvider)}>
              Continuer avec Google
            </Button>
            <Button variant="outline" className="h-12 text-lg font-medium" onClick={() => handleLogin(githubProvider)}>
              Continuer avec GitHub
            </Button>
            <Button variant="outline" className="h-12 text-lg font-medium" onClick={() => handleLogin(facebookProvider)}>
              Continuer avec Facebook
            </Button>
            <Button variant="outline" className="h-12 text-lg font-medium" onClick={() => handleLogin(appleProvider)}>
              Continuer avec Apple
            </Button>
          </div>

          <div className="text-center text-xs text-muted-foreground pt-4">
            En continuant, vous acceptez nos conditions d'utilisation.
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-background text-foreground transition-colors duration-300 overflow-hidden">
      <Toaster position="top-center" richColors />
      
      {/* --- Sidebar (Desktop) --- */}
      <aside className="hidden md:flex flex-col w-80 border-r bg-card/50 backdrop-blur-xl">
        <div className="p-4 border-bottom flex items-center justify-between">
          <h2 className="text-xl font-bold">AMPT Chat IA</h2>
        </div>

        <div className="p-4">
          <Button className="w-full justify-start gap-2 h-12 text-lg" onClick={createNewChat}>
            <Plus className="w-5 h-5" /> Nouveau Chat
          </Button>
        </div>

        <ScrollArea className="flex-1 px-4">
          <div className="space-y-2">
            {chats.map((chat) => (
              <div 
                key={chat.id}
                className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${currentChatId === chat.id ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'}`}
                onClick={() => setCurrentChatId(chat.id)}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <MessageSquare className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate text-sm font-medium">{chat.title}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={`opacity-0 group-hover:opacity-100 h-8 w-8 ${currentChatId === chat.id ? 'hover:bg-primary-foreground/20' : ''}`}
                  onClick={(e) => { e.stopPropagation(); deleteChat(chat.id); }}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="p-4 border-t bg-card">
          <DropdownMenu>
            <DropdownMenuTrigger render={<Button variant="ghost" className="w-full justify-start gap-3 h-14 p-2" />}>
              <Avatar className="w-10 h-10 border-2 border-primary/20">
                <AvatarImage src={user.photoURL || ''} />
                <AvatarFallback>{user.displayName?.[0] || 'U'}</AvatarFallback>
              </Avatar>
              <div className="flex flex-col items-start overflow-hidden">
                <span className="text-sm font-bold truncate w-full">{user.displayName}</span>
                <span className="text-xs text-muted-foreground truncate w-full">{user.email}</span>
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <DropdownMenuItem className="gap-2" onClick={() => toast.info('Profil bientôt disponible')}>
                <User className="w-4 h-4" /> Profil
              </DropdownMenuItem>
              <Dialog>
                <DialogTrigger render={<DropdownMenuItem className="gap-2" onSelect={(e) => e.preventDefault()} />}>
                  <Settings className="w-4 h-4" /> Paramètres
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Paramètres</DialogTitle>
                    <DialogDescription>Personnalisez votre expérience AMPT Chat IA.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Notifications</Label>
                        <p className="text-xs text-muted-foreground">Recevoir des alertes personnalisées.</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Mode Sombre</Label>
                        <p className="text-xs text-muted-foreground">Basculer entre le thème clair et sombre.</p>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => setIsDarkMode(!isDarkMode)}>
                        {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Dialog>
                <DialogTrigger render={<DropdownMenuItem className="gap-2" onSelect={(e) => e.preventDefault()} />}>
                  <Key className="w-4 h-4" /> Mes Clés API
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Gestion des Clés API</DialogTitle>
                    <DialogDescription>
                      Générez des clés API pour intégrer AMPT Chat IA dans vos propres projets ou entreprises.
                      <code className="bg-muted p-1 rounded text-xs mt-2 block">
                        POST {window.location.origin}/api/v1/chat
                      </code>
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-6 py-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-muted-foreground">Utilisez ces clés pour intégrer AMPT Chat IA dans vos projets.</p>
                      <Button onClick={generateUserApiKey}>Générer une clé</Button>
                    </div>
                    <div className="space-y-4">
                      {apiKeys.map(k => (
                        <div key={k.id} className="flex items-center justify-between p-4 rounded-xl border bg-accent/50">
                          <div className="space-y-1">
                            <p className="font-bold">{k.name}</p>
                            <code className="text-xs bg-background p-1 rounded">{k.key.slice(0, 10)}...{k.key.slice(-5)}</code>
                          </div>
                          <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(k.key); toast.success('Copié !'); }}>
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <DropdownMenuItem className="gap-2 text-destructive" onClick={handleLogout}>
                <LogOut className="w-4 h-4" /> Déconnexion
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* --- Main Chat Area --- */}
      <main className="flex-1 flex flex-col relative">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b bg-card/80 backdrop-blur-md sticky top-0 z-10">
          <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
            <SheetTrigger render={<Button variant="ghost" size="icon" />}>
              <Menu className="w-6 h-6" />
            </SheetTrigger>
            <SheetContent side="left" className="w-80 p-0">
              {/* Sidebar content repeated for mobile */}
              <div className="flex flex-col h-full bg-card">
                <div className="p-4 border-b flex items-center justify-between">
                  <h2 className="text-xl font-bold">AMPT Chat IA</h2>
                </div>
                <div className="p-4">
                  <Button className="w-full justify-start gap-2" onClick={createNewChat}>
                    <Plus className="w-5 h-5" /> Nouveau Chat
                  </Button>
                </div>
                <ScrollArea className="flex-1 px-4">
                  <div className="space-y-2">
                    {chats.map((chat) => (
                      <div 
                        key={chat.id}
                        className={`flex items-center justify-between p-3 rounded-xl cursor-pointer ${currentChatId === chat.id ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'}`}
                        onClick={() => { setCurrentChatId(chat.id); setIsSidebarOpen(false); }}
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          <MessageSquare className="w-4 h-4" />
                          <span className="truncate text-sm font-medium">{chat.title}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </SheetContent>
          </Sheet>
          <h1 className="text-lg font-bold">AMPT Chat IA</h1>
          <div className="w-10" /> {/* Spacer to keep title centered */}
        </header>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4 md:p-8">
          <div className="max-w-4xl mx-auto space-y-8">
            {messages.length === 0 && (
              <div className="h-[60vh] flex flex-col items-center justify-center text-center space-y-6">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="p-6 rounded-full bg-primary/10"
                >
                  <MessageSquare className="w-16 h-16 text-primary" />
                </motion.div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold">Comment puis-je vous aider ?</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Posez-moi n'importe quelle question, analysez des fichiers ou générez des images avec <Badge variant="secondary">/image</Badge>
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg">
                  {[
                    "Qui t'a créé ?",
                    "Fais-moi un résumé de ce PDF",
                    "Génère une image d'un futuriste Niger",
                    "Traduis 'Bonjour' en 10 langues"
                  ].map((suggestion) => (
                    <Button 
                      key={suggestion}
                      variant="outline" 
                      className="h-auto py-3 px-4 justify-start text-left whitespace-normal hover:border-primary/50"
                      onClick={() => setInput(suggestion)}
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-4 ${msg.role === 'assistant' ? 'justify-start' : 'justify-end'}`}
              >
                {msg.role === 'assistant' && (
                  <Avatar className="w-10 h-10 border-2 border-primary/20 flex-shrink-0">
                    <AvatarImage src="/logo.png" />
                    <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                )}
                <div className={`max-w-[85%] space-y-2 ${msg.role === 'user' ? 'order-first' : ''}`}>
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    msg.role === 'assistant' 
                      ? 'bg-card border border-primary/10' 
                      : 'bg-primary text-primary-foreground'
                  }`}>
                    {msg.type === 'image' ? (
                      <div className="space-y-3">
                        <img src={msg.mediaUrl} alt="Generated" className="rounded-lg w-full max-w-sm" referrerPolicy="no-referrer" />
                        <p className="text-sm">{msg.content}</p>
                      </div>
                    ) : (
                      <div className="prose dark:prose-invert max-w-none text-sm leading-relaxed">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    )}
                  </div>
                  {msg.role === 'assistant' && (
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => speakText(msg.content)}>
                        <Volume2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { navigator.clipboard.writeText(msg.content); toast.success('Copié !'); }}>
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                {msg.role === 'user' && (
                  <Avatar className="w-10 h-10 border-2 border-primary/20 flex-shrink-0">
                    <AvatarImage src={user.photoURL || ''} />
                    <AvatarFallback>{user.displayName?.[0]}</AvatarFallback>
                  </Avatar>
                )}
              </motion.div>
            ))}
            {isProcessing && (
              <div className="flex gap-4 justify-start">
                <Avatar className="w-10 h-10 border-2 border-primary/20 animate-pulse">
                  <AvatarFallback>AI</AvatarFallback>
                </Avatar>
                <div className="bg-card p-4 rounded-2xl border border-primary/10">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 md:p-8 border-t bg-card/50 backdrop-blur-xl">
          <form 
            onSubmit={sendMessage}
            className="max-w-4xl mx-auto relative flex items-end gap-2"
          >
            <div className="flex-1 relative bg-background rounded-2xl border-2 border-primary/20 focus-within:border-primary transition-all shadow-lg">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="Posez votre question ici..."
                className="w-full bg-transparent p-4 pr-24 resize-none max-h-40 min-h-[56px] focus:outline-none"
                rows={1}
              />
              <div className="absolute right-2 bottom-2 flex items-center gap-1">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  onChange={handleFileUpload}
                  accept="image/*,application/pdf,audio/*"
                />
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 text-muted-foreground hover:text-primary"
                  onClick={startVoiceRecognition}
                >
                  <Mic className="w-5 h-5" />
                </Button>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 text-muted-foreground hover:text-primary"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Plus className="w-5 h-5" />
                </Button>
                <Button 
                  type="submit" 
                  size="icon" 
                  disabled={!input.trim() || isProcessing}
                  className="h-10 w-10 rounded-xl"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </form>
          <p className="text-[10px] text-center mt-2 text-muted-foreground">
            AMPT Chat IA peut faire des erreurs. Vérifiez les informations importantes.
          </p>
        </div>
      </main>
    </div>
  );
}
